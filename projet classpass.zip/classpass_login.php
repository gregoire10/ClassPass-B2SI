<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $nom = strtolower(trim($_POST['nom'])); // Convertir en minuscules et supprimer les espaces inutiles
    $prenom = strtolower(trim($_POST['prenom'])); // Convertir en minuscules et supprimer les espaces inutiles
    $role = $_POST['role'];

    // Valider les données
    if (empty($nom) || empty($prenom) || empty($role)) {
        die("Tous les champs sont obligatoires.");
    }

    // Générer l'email et le mot de passe en fonction du rôle
    if ($role == "admin") {
        $email = $nom . '.' . $prenom . '@classpassAD.com';
        $password = 'ClassPass' . ucfirst($prenom) . '@AD'; // Mot de passe pour l'administrateur
    } elseif ($role == "student") {
        $email = $nom . '.' . $prenom . '@classpassST.com';
        $password = 'ClassPass' . ucfirst($prenom) . '@ST'; // Mot de passe pour l'étudiant
    } else {
        die("Rôle invalide."); // Gérer les erreurs si le rôle n'est pas valide
    }

    // Afficher les résultats
    echo "<h2>Résultats :</h2>";
    echo "<p><strong>Email :</strong> " . htmlspecialchars($email) . "</p>";
    echo "<p><strong>Mot de passe :</strong> " . htmlspecialchars($password) . "</p>";
} else {
    // Rediriger vers le formulaire si la méthode n'est pas POST
    header("Location: index.html");
    exit();
}
?>